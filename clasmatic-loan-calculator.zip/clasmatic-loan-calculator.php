<?php
/*
Plugin Name: Clasmatic Loan Calculator
Description: Calculates loan and displays repayment schedule. Use [clasmatic_loan_calculator] to show calculator.
Version: 2.0.0
Author: Milind Savardekar
Author URI: https://www.clasmatic.com/
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
*/

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Enqueue necessary scripts and stylesheets
function clasmatic_loan_calculator_enqueue_scripts() {
    wp_enqueue_script('jquery-ui-slider');
}
add_action('wp_enqueue_scripts', 'clasmatic_loan_calculator_enqueue_scripts');

// Add a shortcode to display the loan calculator form
function clasmatic_loan_calculator_shortcode() {
    ob_start();
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>Loan Calculator</title>
        <style>
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.6);
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        .loan-amount-tooltip {
            position: relative;
        }

        .loan-amount-tooltip::after {
            content: attr(data-tooltip);
            position: absolute;
            top: -25px;
            left: 50%;
            transform: translateX(-50%);
            padding: 5px;
            background-color: #333;
            color: #fff;
            font-size: 12px;
            border-radius: 3px;
            white-space: nowrap;
            opacity: 0;
            visibility: hidden;
            transition: opacity 0.3s ease, visibility 0.3s ease;
        }

        .loan-amount-tooltip:hover::after {
            opacity: 1;
            visibility: visible;
        }

        </style>
        <script>
        function calculateLoan() {
            var amount = document.getElementById("loanAmount").value;
            var interestRate = document.getElementById("interestRate").value;
            var months = document.getElementById("loanTerm").value;

            var monthlyRate = interestRate / 100 / 12;
            var monthlyPayment = (amount * monthlyRate) / (1 - Math.pow(1 + monthlyRate, -months));

            document.getElementById("monthlyPayment").innerHTML = monthlyPayment.toFixed(2);

            var repaymentTable = document.getElementById("repaymentSchedule");
            repaymentTable.innerHTML = "";

            var headerRow = repaymentTable.insertRow();
            var monthHeader = headerRow.insertCell(0);
            monthHeader.innerHTML = "<b>Month</b>";
            var paymentHeader = headerRow.insertCell(1);
            paymentHeader.innerHTML = "<b>Payment</b>";
            var interestHeader = headerRow.insertCell(2);
            interestHeader.innerHTML = "<b>Interest</b>";
            var balanceHeader = headerRow.insertCell(3);
            balanceHeader.innerHTML = "<b>Balance</b>";

            for (var i = 1; i <= months; i++) {
                var newRow = repaymentTable.insertRow();
                var monthCell = newRow.insertCell(0);
                var paymentCell = newRow.insertCell(1);
                var interestCell = newRow.insertCell(2);
                var balanceCell = newRow.insertCell(3);

                monthCell.innerHTML = i;
                paymentCell.innerHTML = monthlyPayment.toFixed(2);

                var interest = amount * monthlyRate;
                interestCell.innerHTML = interest.toFixed(2);

                var principal = monthlyPayment - interest;
                balanceCell.innerHTML = (amount - principal).toFixed(2);

                amount = amount - principal;
            }
        }
        </script>
    </head>
    <body>
    <div class="container">
        <h1>Clasmatic Loan Calculator</h1>

        <label for="loanType">Loan Type:</label>
        <select id="loanType" onchange="calculateLoan()">
            <option value="personal">Personal Loan</option>
            <option value="car">Car Loan</option>
            <option value="mortgage">Mortgage Loan</option>
            <option value="business">Business Loan</option>
            <option value="student">Student Loan</option>
            <option value="hospital">Hospital Loan</option>
            <option value="traveling">Traveling Loan</option>
            <!-- Add additional loan types as needed -->
        </select>

        <br><br>

        <label for="loanAmount" class="loan-amount-tooltip" data-tooltip="Select loan amount">Loan Amount:</label>
        <input type="range" id="loanAmount" min="100" max="10000000" step="100" value="10000000" oninput="calculateLoan()">
        <span id="loanAmountDisplay">1,00,00,000</span>

        <br><br>

        <label for="interestRate">Interest Rate (%):</label>
        <input type="number" id="interestRate" min="0" max="20" step="0.1" value="5" oninput="calculateLoan()">

        <br><br>

        <label for="loanTerm">Loan Term (months):</label>
        <input type="number" id="loanTerm" min="1" max="60" value="12" oninput="calculateLoan()">

        <br><br>

        <h2>Monthly Payment: $<span id="monthlyPayment">0.00</span></h2>

        <h2>Repayment Schedule:</h2>
        <table id="repaymentSchedule">
            <tr>
                <th>Month</th>
                <th>Payment</th>
                <th>Interest</th>
                <th>Balance</th>
            </tr>
        </table>

        <script>
        // Display the initial loan amount value
        document.getElementById("loanAmountDisplay").innerHTML = document.getElementById("loanAmount").value;

        // Calculate the loan initially
        calculateLoan();


        // Update the loan amount display when the range input changes
        function updateLoanAmountDisplay() {
            var loanAmount = document.getElementById("loanAmount").value;
            document.getElementById("loanAmountDisplay").textContent = numberWithCommas(loanAmount);
        }

        // Format the loan amount with commas for better readability
        function numberWithCommas(amount) {
            return amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        }

        // Call the updateLoanAmountDisplay() function initially
        updateLoanAmountDisplay();

        // Add an event listener to the loanAmount range input
        document.getElementById("loanAmount").addEventListener("input", function() {
            updateLoanAmountDisplay();
            calculateLoan();
        });



        </script>

        <h1>Developed By <a href="https://www.clasmatic.com">Clasmatic.com</a></h1>
    </div>
    </body>
    </html>
    <?php
    return ob_get_clean();
}
add_shortcode('clasmatic_loan_calculator', 'clasmatic_loan_calculator_shortcode');
